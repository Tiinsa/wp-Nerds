<?php
/**
 * The template for displaying a audio media
 *
 *
 * @package Customizr
 */
?>
<div class="audio-container <?php czr_fn_echo( 'element_class' ) ?>" <?php czr_fn_echo( 'element_attributes' ) ?>>
  <?php czr_fn_echo( 'audio' ) ?>
</div>