<?php
/**
 * The template for displaying the header search contaienr
 */
?>
<<?php czr_fn_echo('element_tag') ?> class="header-search__container <?php czr_fn_echo( 'element_class' ) ?>">
  <?php get_search_form() ?>
</<?php czr_fn_echo('element_tag') ?>>