<?php
/* silence is golden */
