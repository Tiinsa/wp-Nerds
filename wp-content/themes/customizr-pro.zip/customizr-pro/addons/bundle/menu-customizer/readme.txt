> Add beautiful side menu to the Customizr theme

# Changelog
= v1.0.1 August 19th 2015 =
* Fix: properly switch on slide-on-top effect when wp_is_mobile()

= v1.0.0 Jul 28th 2015 =
* initial release
