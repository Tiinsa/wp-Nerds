> Add beautiful effects to your blog post grid in the Customizr WordPress theme.

# Changelog
= v1.0.4 July 26th 2015 =
* fix: gc_update_setting_control_map() function error when adding setting since latest customizr update
* fix: darker entry-title background

= v1.0.3 May 15th 2015 =
* fix: properly pass sanitize_callback, fix issue with wp<4.1
* fix: customize compatible code with old wp versions
* fix : more contrast to the post titles with a darker background

= v1.0.2 April 29th 2015 =
* fix : effect-5 title style
* added : when the grid customizer is enabled, the user can now set a custom excerpt length without limitations

= v1.0.1 March 27th 2015 =
* added : new options for titles and post backgrounds

= v1.0.0 March 26th 2015 =
* initial release