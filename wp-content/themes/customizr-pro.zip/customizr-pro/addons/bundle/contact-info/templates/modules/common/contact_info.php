<?php
 /**
  * The template for displaying the contact info
  *
  */
?>
<ul class="czr-contact-info <?php czr_fn_echo('element_class')?>" <?php czr_fn_echo('element_attributes') ?>>
  <?php czr_fn_echo( 'contact_info' ) ?>
</ul>