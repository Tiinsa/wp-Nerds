![Footer Customizer](/footer-customizer.jpg)
> Customize the footer credits of the Customizr WordPress theme.

# Copyright
Footer Customizer is a WordPress plugin designed and developed by Nicolas Guillaume (nikeo) in Nice, France (presscustomizr.com), and distributed under the terms of the GNU GPL v2.0 or later.
Enjoy it!

# Licenses
Unless otherwise specified, all the theme files, scripts and images
are licensed under GNU General Public License version 2, see file license.txt.


# DOCUMENTATION AND SUPPORT
DOCUMENTATION : http://presscustomizr.com/extension/footer-customizer/
SUPPORT : http://presscustomizr.com/support-forums/


# Changelog
= 1.0.3 September 21st 2015 =
* Imp: various FC improvements and lang plugins compatibility
* Imp: allow html in copyright and credit text

= 1.0.2 August 19th 2015 =
* fix default footer link was pointing to themesandco.com
* fix make the credits filter return the html rather than print it

= 1.0.1 =
* fix bug when adding a new section in the customizer
* fix option prefix issues since v3.4
* fix escape options on output

= 1.0.0 =
* initial release
