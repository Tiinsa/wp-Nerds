<?php
/* silence is golden */
