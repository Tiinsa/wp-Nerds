<?php
class CZR_menu_button_model_class extends CZR_Model {
  public $defaults = array(
    'data_attributes' => 'data-toggle="czr-collapse" data-target="#mobile-nav"',
    'element_tag'     => 'li',
    'element_class'   => ''
  );
}//end class